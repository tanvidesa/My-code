""""""
"""
Function with parameters

def sample(a):
    # a is a parameter/ an argument
    print(a)

sample(10)
sample('python')
---------
How many parameters we can supply?
Ans: n
======================
def sample(a,b,c):
    print(a)
    print(b)
    print(c)

sample(1,2,3)
# Rule: in declaration if we have 3 args
# then u must supply 3 values
# Rule: when we supply direct values
# these values are positional one
sample('A','B','C')
sample('depali','pune',411011)
# in values we can supply any type of data
=========================
def sample(a,b,c):
    print(a,b,c)
sample('java','c','python')
===================
Types of arguments:
1. Positional arguments: follows sequence order
Example:

def info(name,age,place):
    print('name:',name)
    print('age:',age)
    print('place:',place)

info('Saurabh',30,'Satara')
# but if we change sequence then???
info(21,'Seema','Latur')
# in above case positional arg create a problem
# as we are not following a sequence
==========================================
2. Keyword argument:here sequence doesnt matter
bcz we give a reference with args
Example:

def info(name,age,place):
    print('name:',name)
    print('age:',age)
    print('place:',place)

info('Saurabh',30,'Satara')
# now we r taking help of arguments itself
# to allocate values properly
info(age=21,name='Seema',place='Latur')

=================================
3. Default argument: in declaration itself
we can set a value as a default value
Rule: if we have nt give value for default arg then it will
take default value,otherwise it will tk the value
given by a user
==================
def info(name,place='Maharashtra'):
    print(name,place)
info('Ankush')
info('Ganesh','Kolhapur')
=====================
# When non-default argument follows default argument
# its not allowed as per suntax
def info(place='Maharashtra',name):
    print(name,place)
info('Ankush')
info('Ganesh','Kolhapur')
-------------------------
def show(p,q,r=400):
    print(p,q,r)
# in above case p,q are positional args
# r is default arg.
# so r should always follow p,q
show(10,20)
------------------
def show(r=400,p,q): #not allowed
    print(p,q,r)
# in above case p,q are positional args
# r is default arg.
# so r should always follow p,q
show(10,20)
============================
4. Variable length argument:multiple values u can supply
at the time of calling
or u may kep calling empty
it has 2 types:
1. Variable length positional args
in order make a normal variable as a variable length
use * infront of that variable
Example:
def func(*var):
------------------
def show(*n):
    print(n)

show(1)
show('py','c','c#')
show(-1,-2,-3,-4,-5,-6)
show()
---------------------
It returns tuple as an output
-----------------------
2. Variable length keyword args
in order make a normal variable as a variable length
keyword arg
use ** infront of that variable
second imp things,
supply the values as keyword args
Example:
def func(**var):
========================

def show(**n):
    print(n)
show(a=10,b=20)
show()
show(name='anil',age=45,place='pune')

It returns result in dict format
===========================
var len positional: *args

def info(*args):
    print(args)
info()
info(1,2,3)
info('ramesh',33,45000)
--------------------------------
var len keyword: **kwargs

def info(**kwargs):
    print(kwargs)
info()
info(p=1,q=2,r=3)
info(nm='ramesh',ag=33,s=45000)
============================
ASSIGNMENT:
What is difference between *args and **kwargs?
*args                 **kwargs
"""

















