""""""
"""
PS: Take a name from user, and print in reverse order

nm = input('Enter your name:')
print(nm)
#-----------
print(nm[::-1])
#----------
n = reversed(nm)
print(''.join(list(n)))
#------Without builtin-----------
nm = input('Enter your name:')
for i in range(-1,-(len(nm)+1),-1):
    print(nm[i],end='')
----------------------------------
nm = input('Enter your name:')
s = ''
for i in nm:
    s = i + s
print(s)
-------------------------
nm='Ganesh'
print(''.join([i for i in nm[::-1]]))
=================================
nm = 'Sachin Ramesh Tendulkar'
# PS: Reverse fname and Lastname
j = nm.split()
print(j[::-1])
e = ''
for i in j[::-1]:
    #print(i,end=' ')
    e +=i+' '
print(e)
=============================
j = ['amit','subhash','nik']
print(sorted(j,key=len))
===============================
k = [('Amit',58),('Anita',67),('Ankit',89),('Shubham',40)]
# Sort the list in Descending order on the basis of Marks
print(sorted(k,key=lambda x:x[1]))
print(sorted(k,key=lambda x:x[1],reverse=True))

def marks(x):
    return x[1]
print(sorted(k,key=marks))
===========================

k = [('Amit',58),('Anita',67),('Ankit',89),('Shubham',40)]
#PS: I want dict from k
d = {}
#d['sushant']=80
#print(d)
for i in k:
    #print(i[1])
    d[i[0]] = i[1]
print(d)
=============================
k = [('Amit',58),('Anita',67),('Ankit',89),('Shubham',40)]
print(dict(k))
================================
k = [('Amit',58),('Anita',67),('Ankit',89),('Shubham',40)]
print({i[0]:i[1] for i in k})
===========================================
Decorator
Generator
Iterator
"""















