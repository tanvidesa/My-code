""""""
"""
Higher Order functions:
A function who takes another function as an input
Apply that input function over the sequence and generates a result
These functions are Higher order functions
==> simple convention: function(input_function,sequence/iterable)
an input_function==> it may b a normal function/lambda function
sequence/iterable: collection of elements Ex. list,string,tuple, set,dict,range

Higher order functions are of 3 types:
1. filter function
2. map function
3. reduce function
========================================
1. Filter function: filters the value from a sequence based on condition specified
in an input function
- Supply only name of an input function
- filter will result filter object
- to see an output either u typecast or use for loop
Syntax:
filter(function,iterable)
Hence its condition based
----------------------
Example:
val = [12,5,9,0,3,55,78,100]
# filter only EVEN numbers from a sequence val
eve = lambda num:num %2==0
#print(eve(12))
print(list(filter(eve,val)))
# eve is an input function
# this ill be applied of each num from val
# wherever the result is True
# it wil return that value
--------------------------------
#PS: filter/fetch name whose len is >5 charachter
nm = ['rupesh','sheetal','abhishek','sham','vikas']
test = lambda name:len(name)>5
#print(list(filter(test,nm)))

# 2nd approach to see the result of filter function
out =filter(test,nm)
print(out)
for result in out:
    print(result)


for result in filter(test,nm):
    print(result)
    
===================================
#PS: filter/fetch name whose len is >5 charachter
nm = ['rupes','sheetal','abhishek','sham','vikas']
# use lambda function directly as an input inside a filter
print(tuple(filter(lambda names:len(names)>5,nm)))

#PS: filter name ends with s char
print(tuple(filter(lambda names:names.endswith('s'),nm)))
==================================
2. map function: its a function, which takes input function
and apply input function over each element from a sequence
Hence its operation/expression based
Syntax:
map(func,iter)
- returns output in the form of map object
- hence we need to typecast
-------------------------------
k = [10,20,30,40,50,60]
#PS: add 100 t each element

print(list(map(lambda n:n+100,k)))
# for transforming whole data , map is used
-----------------------
Example
salary = [25000,35000,50000,80000]
#PS: give a Diwali bonus upto 20% on above salary

#Solution using a normal function
def bonus(sal):
    return sal + sal*.2
#print(bonus(12000))

print(salary)
print(list(map(bonus,salary)))

# Solution by a lambda function
print(list(map(lambda sal:sal + sal*.2,salary)))
-----------------------

#PS: Convert name into upperCase
nm = ['rupes','sheetal','abhishek','sham','vikas']

print(list(map(lambda nm:nm.upper(),nm)))
print(list(map(lambda nm:len(nm),nm)))
# When u want to perform element by element
# operations then use map
==============================
3. reduce:
- used to reduce a sequence into a single output
- its not a builtin
- it is present in functools module
- hence we need to import reduce from functools
-----------------
How it works
-it takes first object from a sequence
add into second object
- after addtion of 2 object , result will be the next element
and 3rd object becomes a new object which will be addedd 
------------------
Example:

from functools import reduce
k = [10,20,30,40]
#(((10+20)+30)+40)
#PS: addition of all numbers
add = lambda x,y:x+y
print(reduce(add,k))

a = ['A','B','C','D']
print(reduce(lambda x,y:x+y,a))

-------------------------------------
from functools import reduce
k = [3,5,67,100,2,6]
#PS: find out max num from k
print(max(k))

# normal function
def max_f(num1,num2):
    if num1>num2:
        return num1
    else:
        return num2

print(reduce(lambda num1,num2:num1 if num1>num2 else num2,k))
print(reduce(max_f,k))
===============================================
Interview Question:

"""
















