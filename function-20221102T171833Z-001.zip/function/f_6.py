""""""
"""
Higher order functions
1. filter: condition based
2. map: operation based
3. reduce: gives a result as a single object

Ternary Operator
which usually known as conditional expressions. 
It provides a way that we can use one-line code to evaluate 
the first expression if the condition is true, 
otherwise it evaluates the second expression. 

Syntax:
expression_if_true if condition else expression_if_false
===========================
Interview Questions:
map vs filter vs reduce
why we call them higher order function
which one is to use at what time?
-----------------------------------------
LIST COMPREHENSION:
a process which perform operation over the collection of elements
and results a new list
Syntax:
[expression/var for var in sequence]

Example:
print 0-10 numbers
Traditional solution is

e = []
for i in range(11):
    #print(i)
    e.append(i)
print(e)
------------------------
print([i for i in range(11)])
print([i for i in ['A','B','C']])
----------------------------------
#PS: give the list of 0-10 squared numbers
print([i**2 for i in range(11)])
print([i.lower() for i in ['A','B','C']])
======================================
nm = ['amit','suresh','ramesh','mahesh']
#PS resturn name in upper case
# convert names in upper case
print([i.upper() for i in nm])

#PS: Convert in Upper + fetch initial letter of name
print([(i.upper(),i[0]) for i in nm])

print([(i.upper(),i[::-1]) for i in nm])

#PS: display name + len of name
print([(i,len(i)) for i in nm])
======================================
Dict comprehension
syntax:
{expression for i in sequence}
====================
Websites to explore ore about python

geeksforgeeks
programiz
w3school
Journaldev
pynative
==========================
Different examples of list comprehension
Syntax:
[ expression(element) for element in oldList if condition ]

k = [10,40,87,99,20,45,67,10]
# PS: return a new list with squared numbers only for Even category
print([i*i for i in k if i%2==0])

nm = ['amit','suresh','ramesh','mahesh']
#PS: return Captialized formated names ending with sh
print([i.capitalize() for i in nm if i.endswith('sh')])
----------------------------------
Syntax:
[ if_True_return if condition else return_this for element in oldList]

k = [10,40,87,99,20,45,67,10]
#PS: return a list as [Even,Even, Odd....
print(['Even' if i%2==0 else 'Odd' for i in k])

# PS: give 10 extra to Even numbers and 10 less to odd numbers
print([i+10 if i%2==0 else i-10 for i in k])

h = eval(input('Enter the list'))
print(h,type(h))
----------------------
https://www.geeksforgeeks.org/python-list-comprehension/ 
"""
















