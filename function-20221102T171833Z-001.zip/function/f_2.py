""""""
"""
Function
--------------------
def sample():
    print('hello sample')
sample()
-------------------
Variable types:
Local
Global
=========================
x = 100
def sample():
    x = 10
    print(x)
sample()
print(x+200)
=======================
x = 100
def sample():
    #print(x+100)

    # lets try to change value of a global x
    x = x + 100
    print(x)
sample()
# This will give u Unbound Local error

means we are not allowed to change global value
inside a local scope
But if u have a local x then definetly u can change value of it

x = 100
def sample():
    #print(x+100)
    x = 20 # local
    # lets try to change value of a global x
    x = x + 100
    print(x)
sample()

===================
But if we want to change global x value
then??????
ans: use global keyword
example: global var
#------------------
x = 100
def sample():
    global x # it will allows u to change global value inside a local scope
    # lets try to change value of a global x
    x = x + 100
    print(x)
sample()
print(x)
---------------------
Another approach of a function:
Syntax:
def func(paramter/s):
    return 
func()
------------------
return: when we want to return something to the function calling
then will use a return statement/keyword
If we want something to fetch outside the function 
from inside the function then use return


# when no return
def sample():
    pass
print(sample())
# it returns None when no return 
------------------------ 
# when return is given
def sample():
    return 'Pooja'
print(sample())
# it returns specified things along with calling
==============================
General example:

print(print(45))
# print doesnt have return==> None


print(id(45))
# id returns an address of an object
print(help(id))
=======================================
Add 2 number and return the result


def add():
    return 100 + 500
    # addition performed inside
print(add())
# result we r getting outside a function
# using return
==============================
How many values u can return
Ans: n values
# Write a program
def add():
    return 100 + 500
    # addition performed inside
print(add())
#2
result = add()
print(result)
================================
def report():
    check = '+ve'
    if check == '+ve':
        return 'admit'
    else:
        return 'HomeQ'
print(report())
step = report()

if step == 'admit':
    print('check vacant beds')
else:
    print('HomeQ')
==================================
How to return multiple values

a = 20
b = 50
def sample():
    return a+b,a-b,a*b,a/b
print(sample())
# unpack the results
add,sub,mul,div = sample()
print(add,sub,mul,div)
------------------------------
a = 20
b = 50
def sample():
    return a+b,a-b,a*b,a/b

print(sample())
# unpack the results
add,sub,mul,div = sample()
print('addition:',add,'subtraction:',sub,mul,div)

"""

































