""""""
"""
Function:
It is one building block,which contains variables and operations
This single unit is very useful to execute the code inside it, multiple
times.

Syntax:
def function_name(parameters):
    variables
    operations
-----------------------------
2 imp approaches related to a function
1. declaration of a function: creating/writing a complete 
definition of it
Example: Write a function to add 2 numbers
def add(): #declaration
    print(100+400)
----------------
Only declaration doesnt give u an output
to get an output u need to call the function
# Example
calling of a function means
syntax:
function_name()
add()
====================
Function Declaration and calling

def add(): #declaration
    print(100+400)

# calling of add
add()
======================
How many times, we can call a function??
Ans: n times
- Advantage of a function==>Code Re-usability 
 Declaration is only ones, but
 calling is multiple times,as per the need 
------------------------
print(10+20)
a = 3
b = 4
print(10+20)
from math import pi
print(pi)
print(10+20)
----------------------
def add():
    print(10+20)
a = 3
b = 4
add()
from math import pi
print(pi)
add()
add()
-------------------------
def add(a,b):
    print(a+b)
a = 3
b = 4
add(a,b)
from math import pi
print(pi)
add(10,40)
add(300,400)
--------------------------------
We have2 types of function
1. Built in function: present in python itself
Example:
print()
type()
id()
input()

2. User defined function: created by a user as per
business requirement
Example:
def add(a,b):
    print(a+b)
========================
def func(parameters):
    pass
------------------
def add():# declaration
    a = 200 # var a
    b = 100 #var b
    print(a+b) #print func
add() # calling
##############################
Types of variables
1. Local Variables:
these are available only inside the scope/block
outside the block, local var's wil nt be available
-----------------------------
def add():# declaration
    a = 200 # var a
    b = 100 #var b
    print(a+b) #print func
add() # calling
print(a +b)# a, b local var's not accessible outside
-----------------------------
Now,
If a,b i want to access them
inside a function and outside it
then???
MAKE it global
2. Global Variable: which is accessible everywhere
when we declare the variables outside and before 
the declaration of a function
--------------
# global a,b
a = 20
b = 40
def add():
    print('Inside:',a+b)
add()
print('Outside:',a+b)
----------------------
Working of a function: Set debugger on

def add():
    print('hello')

print(100)
a = 20
add()
print(a)
add()
--------------------------
# global vars.
a = 20
b = 30
def sample():
    # local vars.
    a = 1
    b = 2
    print(a+b)

print(a+b)
sample()
print(a+b)
---------------------------------
"""
















































