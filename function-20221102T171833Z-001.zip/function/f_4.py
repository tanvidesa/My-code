""""""
"""
Take inputs from use and supply to a function
---------------------------------
def sample(nm,age,sal):
    print('Name:',nm,'Age:',age,'salary:',sal)

for i in range(3):
    name = input('Enter the name:')
    a = int(input('Enter the age:'))
    salary = float(input('Enter the salary:'))
    sample(nm=name,age=a,sal=salary)
    print('--------------------------')
=============================
BANK APPLICATION
========================
balance = 0.0
name = input('Enter your name:')
print('Welcome',name,'to SBI PUNE KATRAJ BRANCH')
print('You are fresh account holder')
print('Your current balance is Rs:',balance)
print('------------------')
print('We have following options')
print('1.Credit\n2.Debit\n3.Check Balance\n4.Exit')
while True:
    def credit(amt):
        global balance
        balance+=amt
        return balance
    def debit(amt):
        global balance
        balance-=amt
        return balance

    ch = int(input('Enter your choice:'))

    if ch == 1:
        print(name,'You selected Credit option')
        amt = float(input('Enter amount:Rs.'))
        print('Account balance after Credit:Rs.',credit(amt))
    
    elif ch == 2:
        print(name,'You selected Debit option')
        amt = float(input('Enter amount:Rs.'))
        print('Account balance after Debit:Rs.',debit(amt))
=================================================
VVVIMP
Lambda function:
known as Anonymous function
or Nameless function

It has same structure and property of a normal function
but the purpose to introduce this is, whenever we want
to write a function for temp. purpose
and second imp thing is it reduces the code.

Syntax:
lambda parameter/s: expression
lambda: keyword
parameter: arguments
expression: operation [only ONE expression is allowed at a time]
=====================================
Normal func: for squaring the number
def square(num):
    return num*num,num+100
print(square(10))
-------------------------------------
# Using lambda function
sq = lambda num:num*num
print(sq(25))
# lambda function has default return statement

print(square)
print(sq)
------------------------
Example:

# positional args
add = lambda x,y:x+y
print(add(1,2))

# keyword args
sub = lambda x,y:x-y
print(sub(y=100,x=200))

# default arg
conv = lambda nm='Guest':nm.upper()
print(conv())
print(conv('ramesh'))

#var len
var = lambda *args:sum(args)
print(var(10,20))
print(var(1,2,3,4,5))
=================================
test = lambda x,y,z:x*100+y*10
print(test(1,2,3))
===============================
test = lambda x,y,z:(x*100,y*10,z+90)
print(test(1,2,3))
"""

don = lambda nm='Shani':len(nm)
print(don())
print(don('Python'))





















